/**
 * Name: Kaizhong Ying
 * Email: kying@andrew.cmu.edu
 *
 * This class is server TCP class to give the message
 * It receives the signature of server
 * and show verification return to server
 */

import com.google.gson.Gson;
import java.io.*;
import java.math.BigInteger;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.Scanner;

public class VerifyingServerTCP {
    private static Socket clientSocket = null;
    private static int serverPort = 7777;
    private static ResponseMessage responseMessage = new ResponseMessage();
    private static RequestMessage requestMessage = new RequestMessage();
    private static BlockChain blockChain;
    private static Gson gson = new Gson();

    public static void main(String[] args) {
        // Initialize the blockchain and first block
        blockChain = new BlockChain();
        Block init = new Block(blockChain.getChainSize(), blockChain.getTime(), "Genesis", 2);
        blockChain.addBlock(init);
        blockChain.computeHashesPerSecond();
        try{
            // Basic TCP server
            ServerSocket listenSocket = new ServerSocket(serverPort);
            System.out.println("Blockchain server running\n");
            clientSocket = listenSocket.accept();
            Scanner in = new Scanner(clientSocket.getInputStream());
            PrintWriter out;
            out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));
            while (true) {
                if (in.hasNextLine()) {
                    String info = in.nextLine();
                    // Generate the output of the server
                    requestMessage = gson.fromJson(info, RequestMessage.class);
                    if(requestMessage.option != 6){
                        System.out.println("We have a visitor");
                    }
                    System.out.println("THE JSON REQUEST MESSAGE IS SHOWN HERE: " + info);
                    generateResponseMessage(requestMessage.option);
                    out.println(gson.toJson(responseMessage));
                    out.flush();
                } else {
                    clientSocket = listenSocket.accept();
                    in = new Scanner(clientSocket.getInputStream());
                    out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())));
                }
                System.out.println();
            }
        } catch (IOException e) {
            System.out.println("IO Exception:" + e.getMessage());
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if(clientSocket != null) clientSocket.close();
            } catch (IOException e) {
            }
        }
    }


    /**
     * A helper method generate the response to client1
     *
     * @param option The user's selection
     */
    public static void generateResponseMessage(int option) throws NoSuchAlgorithmException {
        Timestamp start;
        Timestamp end;
        String response = "";

        switch (option) {
            case 0:
                // Viewing blockchain status

                if (requestMessage != null && verifyRequest(requestMessage)) {
                    responseMessage.verification = "Signature verification successfully";
                    responseMessage.size = blockChain.getChainSize();
                    responseMessage.chainHash = blockChain.getChainHash();
                    responseMessage.totalHashes = blockChain.getTotalExpectedHashes();
                    responseMessage.sumOfDifficulty = blockChain.getTotalDifficulty();
                    responseMessage.nonce = blockChain.getLatestBlock().getNonce();
                    responseMessage.difficulty = blockChain.getLatestBlock().getDifficulty();
                    responseMessage.hashPerSecond = blockChain.getHashesPerSecond();
                    System.out.println("Signature is verified!");
                } else {
                    // If not, show the error message with gson
                    responseMessage.verification = "Error in request";
                    System.out.println("Signature is not verified!");
                }
                break;
            case 1:
                // Adding a transaction
                if (requestMessage != null && verifyRequest(requestMessage)) {
                    responseMessage.verification = "Signature verification successfully";
                    start = blockChain.getTime();
                    blockChain.addBlock(new Block(blockChain.getChainSize(), blockChain.getTime(),
                            requestMessage.data, requestMessage.difficulty));
                    end = blockChain.getTime();
                    response = "Total execution time to add this block was " + (end.getTime() - start.getTime()) + " milliseconds";
                    responseMessage.size = blockChain.getChainSize();
                    responseMessage.chainHash = blockChain.getChainHash();
                    responseMessage.totalHashes = blockChain.getTotalExpectedHashes();
                    responseMessage.sumOfDifficulty = blockChain.getTotalDifficulty();
                    responseMessage.nonce = blockChain.getLatestBlock().getNonce();
                    responseMessage.difficulty = blockChain.getLatestBlock().getDifficulty();
                    responseMessage.hashPerSecond = blockChain.getHashesPerSecond();
                    responseMessage.response = response;
                    System.out.println("Signature is verified!");
                } else {
                    // If not, show the error message with gson
                    responseMessage.verification = "Error in request";
                    System.out.println("Signature is not verified!");
                }
                break;
            case 2:
                // Verifying the blockchain
                if (requestMessage != null && verifyRequest(requestMessage)) {
                    responseMessage.verification = "Signature verification successfully";
                    start = blockChain.getTime();
                    String validation = blockChain.isChainValid();
                    if ("TRUE".equals(validation)) {
                        responseMessage.validationOfChain = "TRUE";
                    } else {
                        responseMessage.validationOfChain = "FALSE";
                        responseMessage.errorMessage = validation;
                    }
                    end = blockChain.getTime();
                    response = "Total execution time required to verify the chain was " +
                            (end.getTime() - start.getTime()) + " milliseconds";
                    responseMessage.response = response;
                    responseMessage.size = blockChain.getChainSize();
                    responseMessage.chainHash = blockChain.getChainHash();
                    responseMessage.totalHashes = blockChain.getTotalExpectedHashes();
                    responseMessage.sumOfDifficulty = blockChain.getTotalDifficulty();
                    responseMessage.nonce = blockChain.getLatestBlock().getNonce();
                    responseMessage.difficulty = blockChain.getLatestBlock().getDifficulty();
                    responseMessage.hashPerSecond = blockChain.getHashesPerSecond();
                    System.out.println("Signature is verified!");
                } else {
                    // If not, show the error message with gson
                    responseMessage.verification = "Error in request";
                    System.out.println("Signature is not verified!");
                }
                break;
            case 3:
                if (requestMessage != null && verifyRequest(requestMessage)) {
                    responseMessage.verification = "Signature verification successfully";
                    responseMessage.response = blockChain.toString();
                    responseMessage.size = blockChain.getChainSize();
                    responseMessage.chainHash = blockChain.getChainHash();
                    responseMessage.totalHashes = blockChain.getTotalExpectedHashes();
                    responseMessage.sumOfDifficulty = blockChain.getTotalDifficulty();
                    responseMessage.nonce = blockChain.getLatestBlock().getNonce();
                    responseMessage.difficulty = blockChain.getLatestBlock().getDifficulty();
                    responseMessage.hashPerSecond = blockChain.getHashesPerSecond();
                    System.out.println("Signature is verified!");
                } else {
                    // If not, show the error message with gson
                    responseMessage.verification = "Error in request";
                    System.out.println("Signature is not verified!");
                }
                break;
            case 4:
                if (requestMessage != null && verifyRequest(requestMessage)) {
                    responseMessage.verification = "Signature verification successfully";
                    int index = requestMessage.index;
                    String corrupt_message = requestMessage.data;
                    blockChain.getBlock(index).setData(corrupt_message);
                    response = "Block " + index + " now holds " + corrupt_message;
                    responseMessage.response = response;
                    responseMessage.size = blockChain.getChainSize();
                    responseMessage.chainHash = blockChain.getChainHash();
                    responseMessage.totalHashes = blockChain.getTotalExpectedHashes();
                    responseMessage.sumOfDifficulty = blockChain.getTotalDifficulty();
                    responseMessage.nonce = blockChain.getLatestBlock().getNonce();
                    responseMessage.difficulty = blockChain.getLatestBlock().getDifficulty();
                    responseMessage.hashPerSecond = blockChain.getHashesPerSecond();
                    System.out.println("Signature is verified!");
                } else {
                    // If not, show the error message with gson
                    responseMessage.verification = "Error in request";
                    System.out.println("Signature is not verified!");
                }
                break;
            case 5:
                if (requestMessage != null && verifyRequest(requestMessage)) {
                    responseMessage.verification = "Signature verification successfully";
                    start = blockChain.getTime();
                    if (!"TRUE".equals(blockChain.isChainValid())) {
                        blockChain.repairChain();
                    }
                    end = blockChain.getTime();
                    response = "Total execution time required to repair the chain was " +
                            (end.getTime() - start.getTime()) + " milliseconds";
                    responseMessage.response = response;
                    responseMessage.size = blockChain.getChainSize();
                    responseMessage.chainHash = blockChain.getChainHash();
                    responseMessage.totalHashes = blockChain.getTotalExpectedHashes();
                    responseMessage.sumOfDifficulty = blockChain.getTotalDifficulty();
                    responseMessage.nonce = blockChain.getLatestBlock().getNonce();
                    responseMessage.difficulty = blockChain.getLatestBlock().getDifficulty();
                    responseMessage.hashPerSecond = blockChain.getHashesPerSecond();
                    System.out.println("Signature is verified!");
                } else {
                    // If not, show the error message with gson
                    responseMessage.verification = "Error in request";
                    System.out.println("Signature is not verified!");
                }
                break;
            default:
                responseMessage.response = "Invalid option selected.";
                break;
        }

        System.out.println("THE JSON RESPONSE MESSAGE IS SHOWN HERE : " + gson.toJson(responseMessage));
        System.out.println("Number of Blocks on Chain == " + blockChain.getChainSize());

    }

    /**
     * The integrate method to verify the request using two separate verification
     * @param requestMessage the request message need to verify
     * @return true if it is verified
     * @throws NoSuchAlgorithmException throw exception when MessageDigest algorithm does not exist
     */
    private static boolean verifyRequest(RequestMessage requestMessage) throws NoSuchAlgorithmException {
        return clientIdMatchesPublicKeyHash(requestMessage) && verifySignature(requestMessage);
    }

    /**
     * Some of the code is copied from project3 task2 ShortMessageVerify.java in GitHub
     * It checks whether clientID matched public key hash
     * @param requestMessage the request message need to verify
     * @return true if it is verified
     * @throws NoSuchAlgorithmException throw exception when MessageDigest algorithm does not exist
     */
    private static boolean clientIdMatchesPublicKeyHash(RequestMessage requestMessage) throws NoSuchAlgorithmException {
        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
        String publicKeyConcat = requestMessage.e + requestMessage.n;
        byte[] publicKeyHash = sha256.digest(publicKeyConcat.getBytes());
        BigInteger computedClientId = new BigInteger(1, java.util.Arrays.copyOfRange
                (publicKeyHash, publicKeyHash.length - 20, publicKeyHash.length));

        return computedClientId.toString(16).equals(requestMessage.clientId);
    }
    /**
     * Some of the code is copied from project3 task2 ShortMessageVerify.java in GitHub
     * It checks the correctness of signature
     * @param requestMessage the request message need to verify
     * @return true if it is verified
     */
    private static boolean verifySignature(RequestMessage requestMessage) {
        BigInteger e = new BigInteger(requestMessage.e);
        BigInteger n = new BigInteger(requestMessage.n);
        BigInteger signature = new BigInteger(requestMessage.signature);

        try {
            MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
            byte[] messageBytes = requestMessage.getMessageToVerify().getBytes();
            byte[] messageHash = sha256.digest(messageBytes);
            BigInteger messageHashInt = new BigInteger(1, messageHash);

            BigInteger decryptedHash = signature.modPow(e, n);
            return messageHashInt.equals(decryptedHash);
        } catch (NoSuchAlgorithmException ex) {
            return false;
        }
    }

    /**
     * The RequestMessage class to receive the request of client
     */
    private static class RequestMessage {
        // The client ID
        private String clientId;
        private String e;
        private String n;
        // represent the option user select
        private int option;
        // represent the difficulty user input
        private int difficulty;
        // represent the index user input
        private int index;
        // represent the data user input
        private String data;


        // The signature of the message to sign
        private String signature;
        /**
         * Default constructor for RequestMessage.
         */
        public RequestMessage() {}

        /**
         * get the string should be verified
         * @return string should be verified
         */
        public String getMessageToVerify() {
            return clientId + e + n + option + difficulty + index + data ;
        }
    }
    /**
     * The ResponseMessage to generate response from server to client
     */
    private static class ResponseMessage {
        // represent size of the blockchain
        private int size;
        // represent difficulty of the latest block
        private int difficulty;
        // represent sum of the difficulties of each block
        private int sumOfDifficulty;
        // represent the hash per second for blockchain
        private int hashPerSecond;
        // represent the total hash of blockchain
        private Double totalHashes;
        // Specify true or false for check the validation of the blockchain
        private String validationOfChain;
        // After check the validation of the blockchain is false, given this message
        private String errorMessage;
        // represent the chain hash
        private String chainHash;
        // The response generated by the server
        private String response;
        // The nonce of latest block in blockchain
        private BigInteger nonce;
        // Response the verification of the request message
        private String verification;
        /**
         * Default constructor for ResponseMessage.
         */
        public ResponseMessage() {}
    }
}
