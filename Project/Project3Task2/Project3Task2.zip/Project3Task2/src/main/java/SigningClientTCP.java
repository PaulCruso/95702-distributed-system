/**
 * Name: Kaizhong Ying
 * Email: kying@andrew.cmu.edu
 *
 * This class is client TCP class to give the message
 * It generates a random RSA key and compute the clientID and signature
 * It sends message which should be verified by server11
 */

import com.google.gson.Gson;

import java.io.*;
import java.math.BigInteger;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Scanner;

public class SigningClientTCP {
    private static Socket clientSocket;
    private static final Scanner SCANNER = new Scanner(System.in);
    private static final RequestMessage requestMessage = new RequestMessage();
    private static ResponseMessage responseMessage = new ResponseMessage();
    private static final Gson gson = new Gson();
    private static BigInteger e, d, n; // RSA public and private keys components
    private static BigInteger clientId; // Client ID derived from public key

    public static void main(String[] args) {
        try {
            int serverPort = 7777;
            clientSocket = new Socket("localhost", serverPort);
            // Simple TCP client input and output
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())),
                    true);
            generateRSAKeys();
            System.out.println("Public Key: (e,n) = (" + e + "," + n + ")");
            System.out.println("Private Key: (d,n) = (" + d + "," + n + ")");
            computeClientId();

            while (true) {
                System.out.println("0. View basic blockchain status.\n" +
                        "1. Add a transaction to the blockchain.\n" +
                        "2. Verify the blockchain.\n" +
                        "3. View the blockchain.\n" +
                        "4. Corrupt the chain.\n" +
                        "5. Hide the corruption by repairing the chain.\n" +
                        "6. Exit.");

                int option = Integer.parseInt(SCANNER.nextLine());
                // Check the validation of the option
                if (option < 0 || option > 6) {
                    System.out.println("Invalid option.");
                    continue;
                }
                // If option equals 6, break the loop
                if (option == 6) break;

                processRequestMessage(option);
                // Send the request message to the server
                String data = gson.toJson(requestMessage);
                out.println(data);
                out.flush();
                responseMessage = gson.fromJson(in.readLine(), ResponseMessage.class);

                displayResponseMessage(option);
            }
        } catch (IOException | NoSuchAlgorithmException e) {
            System.out.println("IO Exception: " + e.getMessage());
        } finally {
            try {
                if (clientSocket != null) {
                    clientSocket.close();
                }
            } catch (IOException ignored) {
            }
        }
    }

    /**
     * A helper method to get the request message
     * @param option the option entered by user
     */
    private static void processRequestMessage(int option) throws NoSuchAlgorithmException {
        requestMessage.option = option;
        if (option == 1) {
            System.out.println("Enter difficulty > 1");
            requestMessage.difficulty = SCANNER.nextInt();
            System.out.println("Enter transaction");
            SCANNER.nextLine();
            requestMessage.data = SCANNER.nextLine();
        } else if (option == 4) {
            System.out.println("Corrupt the Blockchain");
            System.out.println("Enter block ID of block to corrupt");
            int index = SCANNER.nextInt();
            requestMessage.index = index;
            System.out.println("Enter new data for block " + index);
            SCANNER.nextLine();
            requestMessage.data = SCANNER.nextLine();
        }
        requestMessage.clientId = clientId.toString(16);
        requestMessage.e = e.toString();
        requestMessage.n = n.toString();
        requestMessage.signature = signMessage(requestMessage.getMessageToSign());
    }
    /**
     * A helper method to print the response message
     * @param option the option entered by user
     */
    private static void displayResponseMessage(int option) {
        switch (option) {
            case 0:
                if (responseMessage.verification.equals("Signature verification successfully")) {
                    System.out.println("Current size of chain: " + responseMessage.size);
                    System.out.println("Difficulty of most recent block: " + responseMessage.difficulty);
                    System.out.println("Total difficulty for all blocks: " + responseMessage.sumOfDifficulty);
                    System.out.println("Experimented with 2,000,000 hashes.");
                    System.out.println("Approximate hashes per second on this machine: " + responseMessage.hashPerSecond);
                    System.out.println("Expected total hashes required for the whole chain: " + responseMessage.totalHashes);
                    System.out.println("Nonce for most recent block: " + responseMessage.nonce);
                    System.out.println("Chain hash: " + responseMessage.chainHash);
                }else {
                    System.out.println(responseMessage.verification);
                }
                break;
            case 1, 4:
                if (responseMessage.verification.equals("Signature verification successfully")) {
                    System.out.println(responseMessage.response);
                }else {
                    System.out.println(responseMessage.verification);
                }
                break;
            case 2:
                if (responseMessage.verification.equals("Signature verification successfully")) {
                    System.out.println("Chain verification: " + responseMessage.validationOfChain);
                    if (!"TRUE".equals(responseMessage.validationOfChain)) {
                        System.out.println(responseMessage.errorMessage);
                    }
                    System.out.println(responseMessage.response);
                }else {
                    System.out.println(responseMessage.verification);
                }
                break;
            case 3:
                if (responseMessage.verification.equals("Signature verification successfully")) {
                    System.out.println("View the Blockchain");
                    System.out.println(responseMessage.response);
                }else {
                    System.out.println(responseMessage.verification);
                }
                break;
            default: // This handles case 5 and any other unexpected values
                if (responseMessage.verification.equals("Signature verification successfully")) {
                    System.out.println("Repairing the entire chain");
                    System.out.println(responseMessage.response);
                }else {
                    System.out.println(responseMessage.verification);
                }
                break;
        }
    }

    /**
     * This code is copied from Project 3 Task2 RSAExample.java in Github
     * It generates a random RSA key
     */
    private static void generateRSAKeys() {
        SecureRandom rnd = new SecureRandom();
        BigInteger p = new BigInteger(400, 100, rnd);
        BigInteger q = new BigInteger(400, 100, rnd);
        n = p.multiply(q);
        BigInteger phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));
        e = BigInteger.valueOf(65537);
        d = e.modInverse(phi);
    }

    /**
     * Compute the client key by RSA keys
     * the inner clientId is generated by ChatGPT
     * @throws NoSuchAlgorithmException throw exception when MessageDigest algorithm does not exist
     */
    private static void computeClientId() throws NoSuchAlgorithmException {
        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
        byte[] publicKeyHash = sha256.digest((e.toString() + n.toString()).getBytes());
        clientId = new BigInteger(1, java.util.Arrays.copyOfRange(publicKeyHash,
                publicKeyHash.length - 20, publicKeyHash.length));
        System.out.println("Your Client ID: " + clientId.toString(16));
    }

    /**
     * Some of the code is copied from Project 3 Task2 ShortMessageSign.java in Github
     * It helps sign the message given
     * @param message the message need to sign
     * @return the signature of message
     * @throws NoSuchAlgorithmException throw exception when MessageDigest algorithm does not exist
     */
    private static String signMessage(String message) throws NoSuchAlgorithmException {
        MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
        byte[] messageBytes = message.getBytes();
        byte[] messageHash = sha256.digest(messageBytes);
        BigInteger messageHashInt = new BigInteger(1, messageHash);
        BigInteger signature = messageHashInt.modPow(d, n);
        return signature.toString();
    }

    /**
     * The RequestMessage class to receive the request of client
     */
    private static class RequestMessage {
        // The client ID
        private String clientId;
        private String e;
        private String n;
        // represent the option user select
        private int option;
        // represent the difficulty user input
        private int difficulty;
        // represent the index user input
        private int index;
        // represent the data user input
        private String data;
        // The signature of the message to sign
        private String signature;
        /**
         * Default constructor for RequestMessage.
         */
        public RequestMessage() {}

        /**
         * get the string should be signed
         * @return string should be signed
         */
        public String getMessageToSign() {
            return clientId + e + n + option + difficulty + index + data;
        }
    }
    /**
     * The ResponseMessage to generate response from server to client
     */
    private static class ResponseMessage {
        // represent size of the blockchain
        private int size;
        // represent difficulty of the latest block
        private int difficulty;
        // represent sum of the difficulties of each block
        private int sumOfDifficulty;
        // represent the hash per second for blockchain
        private int hashPerSecond;
        // represent the total hash of blockchain
        private Double totalHashes;
        // Specify true or false for check the validation of the blockchain
        private String validationOfChain;
        // After check the validation of the blockchain is false, given this message
        private String errorMessage;
        // represent the chain hash
        private String chainHash;
        // The response generated by the server
        private String response;
        // The nonce of latest block in blockchain
        private BigInteger nonce;
        // Response the verification of the request message
        private String verification;
        /**
         * Default constructor for ResponseMessage.
         */
        public ResponseMessage() {}
    }

}
