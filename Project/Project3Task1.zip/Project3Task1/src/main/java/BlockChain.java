/**
 * Name: Kaizhong Ying
 * Email: kying@andrew.cmu.edu
 *
 * This class represents a simple BlockChain
 * This BlockChain has exactly three instance members
 * an ArrayList to hold Blocks and a chain hash to hold a SHA256 hash of the most recently added Block.
 * This class illustrates a basic blockchain and different methods to modify
 */

import com.google.gson.Gson;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Scanner;

public class BlockChain {
    private ArrayList <Block> blocks;
    private String chainHash;
    private int hashesPerSecond;

    public BlockChain(){
        this.blocks = new ArrayList<Block>();
        this.chainHash = "";
    }

    /**
     * This method add a new block to the blockchain and update the chain hash
     *
     * @param newBlock a block parameter which will add to the blockchain
     */
    public void addBlock(Block newBlock){
        newBlock.setPreviousHash(chainHash);
        blocks.add(newBlock);
        //Set the previous hash
        chainHash = newBlock.proofOfWork();
    }

    /**
     * This method computes a hash of the concatenation of the
     * index, timestamp, data, previousHash, nonce, and difficulty.
     */
    private String calculateHash(String s){
        String hexString;
        try{
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(s.getBytes());
            hexString = Block.bytesToHex(md.digest());
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        return hexString;
    }

    /**
     * This method computes exactly 2 million hashes and times how long that process takes
     * It is run on start up and sets the instance variable hashesPerSecond
     */
    public void computeHashesPerSecond() {
        //Initialize the parameter
        String hashString = "00000000";
        int hashTime = 2000000;
        Timestamp start = getTime();
        // Loop 2000000 times to check
        for (int i = 0; i < hashTime; i++){
            calculateHash(hashString);
        }
        Timestamp end = getTime();
        hashesPerSecond = (int)(hashTime / (end.getTime()-start.getTime()) * 1000);
    }

    /**
     * If the chain only contains one block, the genesis block at position 0
     * this routine computes the hash of the block and
     * checks that the hash has the requisite number of leftmost 0's (proof of work) as specified
     * in the difficulty field. It also checks that the chain hash is equal to this computed hash.
     * If either check fails, return an error message. Otherwise, return the string "TRUE".
     * If the chain has more blocks than one, begin checking from block one.
     * Continue checking until you have validated the entire chain.
     * The first check will involve a computation of a hash in Block 0 and a comparison with the hash pointer in Block 1.
     * If they match and if the proof of work is correct, go and visit the next block in the chain.
     * At the end, check that the chain hash is also correct.
     *
     * @return "TRUE" if chain pass all check, otherwise return the fail reason
     */
    public String isChainValid(){
        for (int i = 0; i < getChainSize(); i++){
            Block currentBlock = getBlock(i);
            String s = currentBlock.calculateHash();
            for(int j = 0; j < currentBlock.getDifficulty(); j++) {
                // Check whether difficulty matches the leading zero
                if(s.charAt(j) != '0')
                    return "Improper hash on node " + i + " does not begin with " +
                            "0".repeat(currentBlock.getDifficulty());
            }
            // Check whether previous hash in current block equal to the previous hash
            if( i != 0 && !getBlock(i-1).calculateHash().equals(currentBlock.getPreviousHash()))
                return "Improper hash on node " + i + " does not match with previous hash";
        }
        // Check the latest node have the chain Hash equal to the compute value;
        if(!getLatestBlock().calculateHash().equals(chainHash))
            return "Improper hash on node " + (getChainSize()-1) + " does not match with the latest hash";

        return "TRUE";
    }

    /**
     * This routine repairs the chain.
     * It checks the hashes of each block
     * and ensures that any illegal hashes are recomputed.
     * After this routine is run, the chain will be valid.
     * The routine does not modify any difficulty values.
     * It computes new proof of work based on the difficulty specified in the Block.
     */
    public void repairChain(){
        String previousHash = "";
        // Update each of the proofOfWork
        for (int i = 0; i < getChainSize(); i++){
            Block block = getBlock(i);
            if (!block.getPreviousHash().equals(previousHash)) {
                block.setPreviousHash(previousHash);
            }
            previousHash = block.proofOfWork();
        }
        chainHash = previousHash;
    }


    /**
     * A getter method to retrieve the certain block
     *
     * @param i the index of the block in blockchain
     * @return the block with specific index
     */
    public Block getBlock(int i){
        return blocks.get(i);
    }
    /**
     * A getter method to retrieve the chain hash
     * @return chain hash of the latest block
     */
    public String getChainHash(){
        return chainHash;
    }
    /**
     * A getter method to retrieve the size of blockchain
     * @return size of blockchain
     */
    public int getChainSize(){
        return blocks.size();
    }
    /**
     * A getter method to retrieve the hashes get per second
     * @return hashes get per second
     */
    public int getHashesPerSecond(){
        return hashesPerSecond;
    }
    /**
     * A getter method to retrieve the latest block
     * @return latest block
     */
    public Block getLatestBlock(){
        return blocks.get(getChainSize()-1);
    }
    /**
     * A getter method to retrieve the system time
     * @return the current system time
     */
    public Timestamp getTime(){
        return new Timestamp(System.currentTimeMillis());
    }
    /**
     * A getter method to retrieve the total difficulty through all blocks
     * @return total difficulty
     */
    public int getTotalDifficulty(){
        int difficulty = 0;
        for (Block block : blocks){
            difficulty += block.getDifficulty();
        }
        return difficulty;
    }
    /**
     * A getter method to retrieve the total expected hashes
     * @return the total expected hashes
     */
    public double getTotalExpectedHashes(){
        double expectedHashes = 0.0;
        for (Block block : blocks){
            // Definition of expected hashes
            expectedHashes += Math.pow(16, block.getDifficulty());
        }
        return expectedHashes;
    }
    /**
     * Override Java's toString method
     *
     * @return A JSON representation of all of this block's data is returned.
     */
    public String toString() {
        BlockChain blockChain = new BlockChain();
        for(int i = 0; i < getChainSize(); i++) {
            blockChain.blocks.add(getBlock(i));
        }
        blockChain.chainHash = getChainHash();
        Gson gson = new Gson();
        return gson.toJson(blockChain);
    }
}
