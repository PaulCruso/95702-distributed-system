/**
 * Name: Kaizhong Ying
 * Email: kying@andrew.cmu.edu
 *
 * This class represents a simple BlockChain
 * This BlockChain has exactly three instance members
 * an ArrayList to hold Blocks and a chain hash to hold a SHA256 hash of the most recently added Block.
 * This class illustrates a basic blockchain and different methods to modify
 */

import com.google.gson.Gson;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Scanner;

public class BlockChain {
    private ArrayList <Block> blocks;
    private String chainHash;
    private int hashesPerSecond;

    public BlockChain(){
        this.blocks = new ArrayList<Block>();
        this.chainHash = "";
    }
    public static void main(String[] args) {
        BlockChain blockChain = new BlockChain();
        Block initialBlock = new Block(blockChain.getChainSize(), blockChain.getTime(), "Genesis", 2);
        blockChain.addBlock(initialBlock);
        Timestamp start;
        Timestamp end;
        int time;
        blockChain.computeHashesPerSecond();
        Scanner scanner = new Scanner(System.in);
        while (true){
            System.out.println("0. View basic blockchain status.\n"+
            "1. Add a transaction to the blockchain.\n" +
            "2. Verify the blockchain.\n" +
            "3. View the blockchain.\n" +
            "4. Corrupt the chain.\n" +
            "5. Hide the corruption by repairing the chain.\n" +
            "6. Exit");
            int option = Integer.parseInt(scanner.nextLine());
            switch (option){
                // For case 0, The number of blocks on the chain Difficulty of most recent block
                // The total difficulty for all blocks Approximate hashes per second on this machine.
                // Expected total hashes required for the whole chain.
                // The computed nonce for most recent block.
                // The chain hash (hash of the most recent block).
                case 0:
                    System.out.println("Current size of chain: " + blockChain.getChainSize());
                    System.out.println("Difficulty of most recent block: " +
                            blockChain.getLatestBlock().getDifficulty());
                    System.out.println("Total difficulty for all blocks: " + blockChain.getTotalDifficulty());
                    System.out.println("Experimented with 2,000,000 hashes.");
                    System.out.println("Approximate hashes per second on this machine: "
                            + blockChain.getHashesPerSecond());
                    System.out.println("Expected total hashes required for the whole chain: "
                            + blockChain.getTotalExpectedHashes());
                    System.out.println("Nonce for most recent block: " +
                            blockChain.getLatestBlock().getNonce());
                    System.out.println("Chain hash: " + blockChain.getChainHash());
                    break;

                // For case 1, it uses addBlock method to add new block to blockchain
                // I increased the difficulty from 2 to 5 for every block I added
                // And every transaction is "distributed system"
                // For difficulty 2, total execution time is 1 millisecond
                // For difficulty 3, total execution time is 19 millisecond
                // For difficulty 4, total execution time is 137 millisecond
                // For difficulty 5, total execution time is 270 millisecond
                // Therefore, as difficulty increase, total execution time also increase a lot
                case 1:
                    System.out.println("Enter difficulty > 1");
                    int difficulty = Integer.parseInt(scanner.nextLine());
                    System.out.println("Enter transaction");
                    String data = scanner.nextLine();
                    start = blockChain.getTime();
                    blockChain.addBlock(new Block(blockChain.getChainSize(), blockChain.getTime(),
                            data, difficulty));
                    end = blockChain.getTime();
                    time = (int) (end.getTime() - start.getTime());
                    System.out.println("Total execution time to add this block was " + time + " milliseconds");
                    break;
                // For case 2, it calls the isChainValid method and display the results.
                // It is important to note that this method will execute fast.
                // Finally, it displays the number of milliseconds it took for validate to run.
                // For our experiment, if chain verification: TRUE
                // Total execution time to verify the chain was 1 millisecond
                // if chain verification: False
                // Total execution time to verify the chain was 1 millisecond
                // So no matter chain is valid or invalid, the execution time is similar
                // This is because no matter chain is valid or invalid
                // it check chain validation loop over the whole blockchain
                case 2:
                    start = blockChain.getTime();
                    String validation = blockChain.isChainValid();
                    end = blockChain.getTime();
                    time = (int) (end.getTime() - start.getTime());
                    System.out.print("Chain verification: ");
                    if (!validation.equals("TRUE")) System.out.println("FALSE");
                    System.out.println(validation);
                    System.out.println("Total execution time to verify the chain was " + time + " milliseconds");
                    break;
                //display the entire Blockchain contents as a correctly formed JSON document.
                case 3:
                    System.out.println("View the Blockchain");
                    System.out.println(blockChain.toString());
                    break;
                // Ask user for the block index (0..size-1)
                // and ask for the new data that will be placed in the block.
                // New data will be placed in the block.
                // At this point, option 2 (verify chain) should show false.
                case 4:
                    System.out.println("Corrupt the Blockchain");
                    System.out.println("Enter block ID of block to corrupt");
                    int index = Integer.parseInt(scanner.nextLine());
                    System.out.println("Enter new data for block " + index);
                    String output = scanner.nextLine();
                    blockChain.getBlock(index).setData(output);
                    System.out.println("Block " + index + " now holds " + output);
                    break;
                //The program begins at the Genesis block and checks each block in turn.
                // If any block is found to be invalid, it executes repair logic.
                // For our experiment I checked the valid and invalid blockchain for repairChain()
                // For valid blockchain, it takes 365 milliseconds to repair
                // For invalid blockchain, it takes 599 milliseconds to repair
                // The invalid blockchain takes longer time
                // This is because invalid blockchain need to find new nonce to repair but valid don't have to
                case 5:
                    start = blockChain.getTime();
                    blockChain.repairChain();
                    end = blockChain.getTime();
                    time = (int) (end.getTime() - start.getTime());
                    System.out.println("Total execution time required to repair the chain was "
                            + time +" milliseconds");
                    break;
                // It will exit the program
                case 6:
                    System.exit(0);
                default:
                    break;
            }
        }
    }

    /**
     * This method add a new block to the blockchain and update the chain hash
     *
     * @param newBlock a block parameter which will add to the blockchain
     */
    public void addBlock(Block newBlock){
        newBlock.setPreviousHash(chainHash);
        blocks.add(newBlock);
        //Set the previous hash
        chainHash = newBlock.proofOfWork();
    }

    /**
     * This method computes a hash of the concatenation of the
     * index, timestamp, data, previousHash, nonce, and difficulty.
     */
    private String calculateHash(String s){
        String hexString;
        try{
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(s.getBytes());
            hexString = Block.bytesToHex(md.digest());
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        return hexString;
    }

    /**
     * This method computes exactly 2 million hashes and times how long that process takes
     * It is run on start up and sets the instance variable hashesPerSecond
     */
    public void computeHashesPerSecond() {
        //Initialize the parameter
        String hashString = "00000000";
        int hashTime = 2000000;
        Timestamp start = getTime();
        // Loop 2000000 times to check
        for (int i = 0; i < hashTime; i++){
            calculateHash(hashString);
        }
        Timestamp end = getTime();
        hashesPerSecond = (int)(hashTime / (end.getTime()-start.getTime()) * 1000);
    }

    /**
     * If the chain only contains one block, the genesis block at position 0
     * this routine computes the hash of the block and
     * checks that the hash has the requisite number of leftmost 0's (proof of work) as specified
     * in the difficulty field. It also checks that the chain hash is equal to this computed hash.
     * If either check fails, return an error message. Otherwise, return the string "TRUE".
     * If the chain has more blocks than one, begin checking from block one.
     * Continue checking until you have validated the entire chain.
     * The first check will involve a computation of a hash in Block 0 and a comparison with the hash pointer in Block 1.
     * If they match and if the proof of work is correct, go and visit the next block in the chain.
     * At the end, check that the chain hash is also correct.
     *
     * @return "TRUE" if chain pass all check, otherwise return the fail reason
     */
    public String isChainValid(){
        for (int i = 0; i < getChainSize(); i++){
            Block currentBlock = getBlock(i);
            String s = currentBlock.calculateHash();
            for(int j = 0; j < currentBlock.getDifficulty(); j++) {
                // Check whether difficulty matches the leading zero
                if(s.charAt(j) != '0')
                    return "Improper hash on node " + i + " does not begin with " +
                            "0".repeat(currentBlock.getDifficulty());
            }
            // Check whether previous hash in current block equal to the previous hash
            if( i != 0 && !getBlock(i-1).calculateHash().equals(currentBlock.getPreviousHash()))
                return "Improper hash on node " + i + " does not match with previous hash";
        }
        // Check the latest node have the chain Hash equal to the compute value;
        if(!getLatestBlock().calculateHash().equals(chainHash))
            return "Improper hash on node " + (getChainSize()-1) + " does not match with the latest hash";

        return "TRUE";
    }

    /**
     * This routine repairs the chain.
     * It checks the hashes of each block
     * and ensures that any illegal hashes are recomputed.
     * After this routine is run, the chain will be valid.
     * The routine does not modify any difficulty values.
     * It computes new proof of work based on the difficulty specified in the Block.
     */
    public void repairChain(){
        String previousHash = "";
        // Update each of the proofOfWork
        for (int i = 0; i < getChainSize(); i++){
            Block block = getBlock(i);
            if (!block.getPreviousHash().equals(previousHash)) {
                block.setPreviousHash(previousHash);
            }
            previousHash = block.proofOfWork();
        }
        chainHash = previousHash;
    }


    /**
     * A getter method to retrieve the certain block
     *
     * @param i the index of the block in blockchain
     * @return the block with specific index
     */
    public Block getBlock(int i){
        return blocks.get(i);
    }
    /**
     * A getter method to retrieve the chain hash
     * @return chain hash of the latest block
     */
    public String getChainHash(){
        return chainHash;
    }
    /**
     * A getter method to retrieve the size of blockchain
     * @return size of blockchain
     */
    public int getChainSize(){
        return blocks.size();
    }
    /**
     * A getter method to retrieve the hashes get per second
     * @return hashes get per second
     */
    public int getHashesPerSecond(){
        return hashesPerSecond;
    }
    /**
     * A getter method to retrieve the latest block
     * @return latest block
     */
    public Block getLatestBlock(){
        return blocks.get(getChainSize()-1);
    }
    /**
     * A getter method to retrieve the system time
     * @return the current system time
     */
    public Timestamp getTime(){
        return new Timestamp(System.currentTimeMillis());
    }
    /**
     * A getter method to retrieve the total difficulty through all blocks
     * @return total difficulty
     */
    public int getTotalDifficulty(){
        int difficulty = 0;
        for (Block block : blocks){
            difficulty += block.getDifficulty();
        }
        return difficulty;
    }
    /**
     * A getter method to retrieve the total expected hashes
     * @return the total expected hashes
     */
    public double getTotalExpectedHashes(){
        double expectedHashes = 0.0;
        for (Block block : blocks){
            // Definition of expected hashes
            expectedHashes += Math.pow(16, block.getDifficulty());
        }
        return expectedHashes;
    }
    /**
     * Override Java's toString method
     *
     * @return A JSON representation of all of this block's data is returned.
     */
    public String toString() {
        BlockChain blockChain = new BlockChain();
        for(int i = 0; i < getChainSize(); i++) {
            blockChain.blocks.add(getBlock(i));
        }
        blockChain.chainHash = getChainHash();
        Gson gson = new Gson();
        return gson.toJson(blockChain);
    }
}
