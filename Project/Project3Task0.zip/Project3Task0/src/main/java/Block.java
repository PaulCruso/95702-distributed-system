/**
 * Name: Kaizhong Ying
 * Email: kying@andrew.cmu.edu
 *
 * This class represents a simple Block
 * Each block has an index, a timestamp, a data field and a String difficulty
 * This class illustrates a basic block and calculation
 */

import com.google.gson.Gson;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Timestamp;
import java.math.BigInteger;

public class Block {
    private int index;
    private Timestamp timestamp;
    private String data;

    private String previousHash;
    private BigInteger nonce;
    private int difficulty;

    private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();

    public Block(int index, Timestamp timestamp, String data, int difficulty){
        this.index = index;
        this.timestamp = timestamp;
        this.data = data;
        this.difficulty = difficulty;
        nonce = new BigInteger(String.valueOf(0));
    }

    // Code from stack overflow
    // https://stackoverflow.com/questions/9655181/how-to-convert-a-byte-array-to-a-hex-string-in-java
    // Returns a hex string given an array of bytes
    public static String bytesToHex(byte[] bytes) {
        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = HEX_ARRAY[v >>> 4];
            hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F];
        }
        return new String(hexChars);
    }
    /**
     * This method computes a hash of the concatenation of the
     * index, timestamp, data, previousHash, nonce, and difficulty.
     *
     * @return a String holding Hexadecimal characters
     */
    public String calculateHash(){
        String blockString = index + timestamp.toString() + data +
                previousHash + nonce + difficulty;
        String hexString;
        try{
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(blockString.getBytes());
            hexString = bytesToHex(md.digest());
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
        return hexString;
    }
    /**
     * The proof of work methods finds a good hash.
     * It increments the nonce until it produces a good hash.
     *
     * @return a String with a hash that has the appropriate number of leading hex zeroes.
     */
    public String proofOfWork() {
        nonce = new BigInteger(String.valueOf(0));
        String hexString;
        while (true) {
            hexString = calculateHash();
            boolean meetsDifficulty = true;
            for (int i = 0; i < difficulty; i++) {
                if (hexString.charAt(i) != '0') {
                    nonce = nonce.add(BigInteger.ONE);
                    meetsDifficulty = false;
                    break;
                }
            }
            if (meetsDifficulty) {
                break;
            }
        }
        return hexString;
    }

    /**
     * A getter method to retrieve the data
     * @return data of the block
     */
    public String getData(){
        return data;
    }
    /**
     * A getter method to retrieve the difficulty
     * @return difficulty of the block
     */
    public int getDifficulty() {
        return difficulty;
    }
    /**
     * A getter method to retrieve the index
     * @return index of the block
     */
    public int getIndex() {
        return index;
    }
    /**
     * A getter method to retrieve the nonce
     * @return nonce of the block
     */
    public BigInteger getNonce() {
        return nonce;
    }
    /**
     * A getter method to retrieve the previous hash
     * @return previous hash of the block
     */
    public String getPreviousHash() {
        return previousHash;
    }
    /**
     * A getter method to retrieve the timestamp
     * @return timestamp of the block
     */
    public Timestamp getTimestamp() {
        return timestamp;
    }
    /**
     * A setter method to set the data
     */
    public void setData(String data) {
        this.data = data;
    }
    /**
     * A setter method to set the difficulty
     */
    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }
    /**
     * A setter method to set the index
     */
    public void setIndex(int index) {
        this.index = index;
    }
    /**
     * A setter method to set the previous hash
     */
    public void setPreviousHash(String previousHash) {
        this.previousHash = previousHash;
    }
    /**
     * A setter method to set the timestamp
     */
    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * Override Java's toString method
     *
     * @return A JSON representation of all of this block's data is returned.
     */
    @Override
    public String toString() {
        Block block = new Block (index, timestamp, data, difficulty);
        block.setPreviousHash(previousHash);
        Gson gson = new Gson();
        return gson.toJson(block);
    }
}
